import{c as d,r as s,f as h,j as e}from"./index-BVLCQBD-.js";/**
 * @license lucide-react v0.487.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const u=[["path",{d:"M22 16.92v3a2 2 0 0 1-2.18 2 19.79 19.79 0 0 1-8.63-3.07 19.5 19.5 0 0 1-6-6 19.79 19.79 0 0 1-3.07-8.67A2 2 0 0 1 4.11 2h3a2 2 0 0 1 2 1.72 12.84 12.84 0 0 0 .7 2.81 2 2 0 0 1-.45 2.11L8.09 9.91a16 16 0 0 0 6 6l1.27-1.27a2 2 0 0 1 2.11-.45 12.84 12.84 0 0 0 2.81.7A2 2 0 0 1 22 16.92z",key:"foiqr5"}]],g=d("phone",u);/**
 * @license lucide-react v0.487.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const f=[["path",{d:"M5 12h14",key:"1ays0h"}],["path",{d:"M12 5v14",key:"s699le"}]],w=d("plus",f);/**
 * @license lucide-react v0.487.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const p=[["path",{d:"M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4",key:"ih7n3h"}],["polyline",{points:"17 8 12 3 7 8",key:"t8dd8p"}],["line",{x1:"12",x2:"12",y1:"3",y2:"15",key:"widbto"}]],j=d("upload",p);/**
 * @license lucide-react v0.487.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const b=[["path",{d:"M18 6 6 18",key:"1bl5f8"}],["path",{d:"m6 6 12 12",key:"d8bk6v"}]],v=d("x",b);function N({isOpen:a,onClose:t,title:l,children:n,size:c="md",footer:o,closeOnBackdrop:i=!0}){if(s.useEffect(()=>{const r=y=>{y.key==="Escape"&&a&&t()};return document.addEventListener("keydown",r),()=>document.removeEventListener("keydown",r)},[a,t]),s.useEffect(()=>(a?document.body.style.overflow="hidden":document.body.style.overflow="unset",()=>{document.body.style.overflow="unset"}),[a]),!a)return null;const x={sm:"max-w-md",md:"max-w-2xl",lg:"max-w-4xl",xl:"max-w-6xl",full:"max-w-7xl mx-4"},m=()=>{i&&t()};return h.createPortal(e.jsx("div",{className:"fixed inset-0 z-[1000] overflow-y-auto animate-fadeIn","data-modal-root":!0,children:e.jsxs("div",{className:"flex min-h-screen items-center justify-center p-4",children:[e.jsx("div",{className:"fixed inset-0 bg-black/60 z-[1001]",onClick:m,"aria-hidden":"true"}),e.jsxs("div",{className:`relative bg-white dark:bg-gray-800 rounded-2xl shadow-2xl ${x[c]} w-full animate-slideUp z-[1002]`,"data-modal-panel":!0,onClick:r=>r.stopPropagation(),children:[e.jsxs("div",{className:"flex items-center justify-between p-6 border-b border-gray-200 dark:border-gray-700",children:[e.jsx("h3",{className:"text-xl dark:text-white",children:l}),e.jsx("button",{onClick:t,className:"text-gray-400 hover:text-gray-600 dark:hover:text-gray-300 transition-colors p-1 hover:bg-gray-100 dark:hover:bg-gray-700 rounded-lg","aria-label":"Close modal",children:e.jsx(v,{className:"w-6 h-6"})})]}),e.jsx("div",{className:"p-6 max-h-[calc(100vh-200px)] overflow-y-auto",children:n}),o&&e.jsx("div",{className:"flex items-center justify-end gap-3 p-6 border-t border-gray-200 dark:border-gray-700 bg-gray-50 dark:bg-gray-700/50 rounded-b-2xl",children:o})]})]})}),document.body)}export{N as M,w as P,j as U,v as X,g as a};
